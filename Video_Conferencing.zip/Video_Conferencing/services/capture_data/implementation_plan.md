# Google Meet Capture Integration — Implementation Plan

Add Google Meet RTP capture and QoE analysis to the existing Microsoft Teams engine. Both platforms share the same retina capture loop, protocol demuxer, session engine, and InfluxDB exporter. They diverge only at the IP-range gate and the CSV output files.

## Data-Flow Overview

```mermaid
graph TD
    A["retina capture loop<br/>(main.rs — unchanged)"] -->|raw frame| B["quick_precheck<br/>(ip_ranges.rs)"]
    B -->|"None"| X["drop"]
    B -->|"Some(Platform::Teams, ...)"| C["identify_protocol<br/>(protocol.rs — unchanged)"]
    B -->|"Some(Platform::Meet, ...)"| C
    C -->|"RTP"| D["parse_rtp_record<br/>(models — adds platform field)"]
    D --> E["RECORD_TX channel"]
    E --> F["records_thread<br/>(channels/record.rs)"]
    F -->|"platform==Teams"| G["teams_rtp_records.csv"]
    F -->|"platform==Meet"| H["meet_rtp_records.csv"]
    F --> I["Batch → session queue"]
    I --> J["SessionEngine<br/>(sessions/mod.rs)"]
    J -->|"is_server_ip uses platform"| K["NetworkMetrics / MediaMetrics / RtpStreams"]
    K --> L["InfluxDB line protocol<br/>(platform tag + T_/M_ session ID)"]
    L --> M["Grafana"]
```

---

## Google Meet Server IP Ranges

These ranges will be used to identify Google Meet traffic (if **either** src or dst matches):

| Type | CIDR | Byte-level check |
|------|------|------------------|
| IPv4 | `74.125.250.0/24` | `[74, 125, 250, *]` |
| IPv4 | `74.125.247.128/32` | `[74, 125, 247, 128]` exact |
| IPv4 | `142.250.82.0/24` | `[142, 250, 82, *]` |
| IPv6 | `2001:4860:4864:5::0/64` | prefix `2001:4860:4864:0005` (8 bytes) |
| IPv6 | `2001:4860:4864:4:8000::/128` | exact 16-byte match |
| IPv6 | `2001:4860:4864:6::/64` | prefix `2001:4860:4864:0006` (8 bytes) |

---

## Proposed Changes

### 1. Models — Platform Enum & RtpRecord

#### [MODIFY] [rtp_record.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/models/rtp_record.rs)

Add the `Platform` enum and a `platform` field to `RtpRecord`:

```diff
+/// Which conferencing platform this packet belongs to.
+#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
+pub enum Platform {
+    Teams,
+    Meet,
+}

 #[derive(Clone, Debug, Serialize)]
 pub struct RtpRecord {
     pub arrival_epoch_ns: u64,
+    pub platform: Platform,
     pub src_ip: String,
     ...
 }
```

- `parse_rtp_record` gains a `platform: Platform` parameter and sets it on the returned struct.

#### [MODIFY] [mod.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/models/mod.rs)

Re-export `Platform`:

```diff
-pub use rtp_record::{RtpRecord, parse_rtp_record};
+pub use rtp_record::{Platform, RtpRecord, parse_rtp_record};
```

---

### 2. IP Filtering — Meet Ranges

#### [MODIFY] [ip_ranges.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/ip_ranges.rs)

Add Google Meet IPv4/IPv6 range checks and change `quick_precheck` return type:

```diff
+use crate::models::Platform;
+
+/// Returns `true` if `ip` belongs to a Google Meet media IPv4 range.
+#[inline(always)]
+pub fn is_meet_ipv4(ip: [u8; 4]) -> bool {
+    match (ip[0], ip[1]) {
+        (74, 125) => ip[2] == 250 || (ip[2] == 247 && ip[3] == 128),
+        (142, 250) => ip[2] == 82,
+        _ => false,
+    }
+}
+
+/// Returns `true` if `ip` (16 bytes, big-endian) belongs to a Google Meet IPv6 range.
+#[inline(always)]
+pub fn is_meet_ipv6(ip: &[u8]) -> bool { ... }

-pub fn quick_precheck(data: &[u8]) -> Option<(bool, usize, usize)> {
+pub fn quick_precheck(data: &[u8]) -> Option<(Platform, bool, usize, usize)> {
```

Logic inside `quick_precheck`:
1. Check Microsoft ranges first → return `Platform::Teams`.
2. Else check Meet ranges → return `Platform::Meet`.
3. Else return `None`.

---

### 3. Main Dispatch

#### [MODIFY] [main.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/main.rs)

- Add new atomic counters: `MEET_RTP_PACKETS`, `MEET_IPV4_PACKETS`, `MEET_IPV6_PACKETS`, etc.
- Update `process_packet` to destructure the new 4-tuple from `quick_precheck`:

```diff
-Some((is_ipv6, ip_start, udp_payload_offset)) => {
+Some((platform, is_ipv6, ip_start, udp_payload_offset)) => {
```

- Pass `platform` through to `parse_rtp_record(data, platform, is_ipv6, ...)`.
- Increment platform-specific counters.
- Update `stats_thread` and final stats to print Teams vs Meet breakdown.

---

### 4. CSV Recording — Dual Writers

#### [MODIFY] [record.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/channels/record.rs)

Open two CSV files and route based on `r.platform`:

```diff
-let file = File::create("teams_rtp_records.csv")...;
-let mut writer = BufWriter::with_capacity(8 * 1024 * 1024, file);
+let teams_file = File::create("teams_rtp_records.csv")...;
+let mut teams_writer = BufWriter::with_capacity(8 * 1024 * 1024, teams_file);
+let meet_file = File::create("meet_rtp_records.csv")...;
+let mut meet_writer = BufWriter::with_capacity(8 * 1024 * 1024, meet_file);
```

Write headers to both, then in the record loop:

```rust
let writer = match r.platform {
    Platform::Teams => &mut teams_writer,
    Platform::Meet  => &mut meet_writer,
};
// write CSV row to `writer`
```

Both records still get pushed to the same `pending` batch for the session engine (no change to batching logic).

---

### 5. Session Engine — Platform-Aware Sessions

#### [MODIFY] [sessions/mod.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/sessions/mod.rs)

Key changes:

1. **Session key** — change from `client_ip` alone to `(client_ip, platform)` so a Teams session and a Meet session from the same IP are tracked independently:

```diff
-self.sessions.entry(client_ip.clone())
+let session_key = format!("{}:{}", platform_prefix, client_ip);
+self.sessions.entry(session_key)
```

2. **Session ID prefix** — prepend `T_` or `M_`:

```diff
-fn new_session_id(client_ip: &str, first_seen_ns: u64) -> String {
+fn new_session_id(platform: Platform, client_ip: &str, first_seen_ns: u64) -> String {
+    let prefix = match platform { Platform::Teams => "T", Platform::Meet => "M" };
     ...
-    format!("{:016x}", hasher.finish())
+    format!("{}_{:016x}", prefix, hasher.finish())
 }
```

3. **`get_client_ip`** — use platform to decide which IP check to use:

```diff
-fn get_client_ip(r: &RtpRecord) -> String {
+fn get_client_ip(r: &RtpRecord) -> String {
+    let is_server = match r.platform {
+        Platform::Teams => is_microsoft_ip(&r.src_ip),
+        Platform::Meet  => is_meet_server_ip(&r.src_ip),
+    };
+    if is_server { r.dst_ip.clone() } else { r.src_ip.clone() }
 }
```

4. **`flush_session`** — add `platform` tag to InfluxDB line protocol:

```diff
-"teams_session_qoe,client_ip={},session_id={} ..."
+"teams_session_qoe,client_ip={},session_id={},platform={} ..."
```

5. **`SessionState`** — add `platform: Platform` field.

---

### 6. Network Metrics — Platform-Aware Server IP Check

#### [MODIFY] [network_metrics.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/sessions/network_metrics.rs)

- Add Google Meet server IP prefixes to a new constant array or a separate check function.
- Change `is_server_ip` to accept platform:

```diff
+const MEET_SERVER_IPS: &[&str] = &[
+    "74.125.250.",
+    "74.125.247.128",
+    "142.250.82.",
+    "2001:4860:4864:5:",
+    "2001:4860:4864:4:8000:",
+    "2001:4860:4864:6:",
+];
+
+pub fn is_meet_server_ip(ip: &str) -> bool {
+    MEET_SERVER_IPS.iter().any(|&prefix| ip.starts_with(prefix))
+}
```

- `process_packet` needs the platform to know which `is_server_ip` function to use. Since `RtpRecord` now carries `platform`, use it:

```diff
-let is_uplink = is_server_ip(&record.dst_ip);
-let is_downlink = is_server_ip(&record.src_ip);
+let (is_uplink, is_downlink) = match record.platform {
+    Platform::Teams => (is_server_ip(&record.dst_ip), is_server_ip(&record.src_ip)),
+    Platform::Meet  => (is_meet_server_ip(&record.dst_ip), is_meet_server_ip(&record.src_ip)),
+};
```

---

### 7. Media Metrics — Use Platform from Record

#### [MODIFY] [media_metrics.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/sessions/media_metrics.rs)

- Update `process_packet` to determine downlink direction using `record.platform`:

```diff
-let is_downlink = is_server_ip(&record.src_ip);
+let is_downlink = match record.platform {
+    Platform::Teams => is_server_ip(&record.src_ip),
+    Platform::Meet  => is_meet_server_ip(&record.src_ip),
+};
```

---

### 8. RTP Stream Tracker — Use Platform from Record

#### [MODIFY] [rtp_streams.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/sessions/rtp_streams.rs)

Same pattern:

```diff
-let is_uplink = is_server_ip(&record.dst_ip);
-let is_downlink = is_server_ip(&record.src_ip);
+let (is_uplink, is_downlink) = match record.platform {
+    Platform::Teams => (is_server_ip(&record.dst_ip), is_server_ip(&record.src_ip)),
+    Platform::Meet  => (is_meet_server_ip(&record.dst_ip), is_meet_server_ip(&record.src_ip)),
+};
```

Also add `platform` tag to the per-SSRC InfluxDB lines so Grafana can filter per-stream data by platform.

---

## Summary of Files Changed

| File | Action | What Changes |
|------|--------|-------------|
| [rtp_record.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/models/rtp_record.rs) | MODIFY | Add `Platform` enum, add `platform` field to `RtpRecord`, add `platform` param to `parse_rtp_record` |
| [models/mod.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/models/mod.rs) | MODIFY | Re-export `Platform` |
| [ip_ranges.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/ip_ranges.rs) | MODIFY | Add `is_meet_ipv4/6`, change `quick_precheck` to return `Platform` |
| [main.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/main.rs) | MODIFY | Handle new 4-tuple, Meet counters, pass `platform` to parser |
| [channels/record.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/channels/record.rs) | MODIFY | Dual CSV writers (Teams + Meet) |
| [sessions/mod.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/sessions/mod.rs) | MODIFY | Platform-aware session keys, `T_`/`M_` session ID prefix, `platform` InfluxDB tag |
| [network_metrics.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/sessions/network_metrics.rs) | MODIFY | Add Meet server IP list, platform-aware direction logic |
| [media_metrics.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/sessions/media_metrics.rs) | MODIFY | Platform-aware downlink check |
| [rtp_streams.rs](file:///Users/rigzennorbu/Desktop/Rigzen/rigzen/services/captures_teams/src/sessions/rtp_streams.rs) | MODIFY | Platform-aware direction + `platform` tag in InfluxDB lines |

## What Stays Exactly the Same

| Component | Why |
|-----------|-----|
| `protocol.rs` (RFC 7983 demux) | WebRTC (Meet) uses the same STUN/DTLS/RTP byte patterns — no changes needed |
| `channels/packet.rs` (PCAP writer) | Both Teams and Meet raw frames go into the same PCAP — they're already distinguished by IP |
| `channels/mod.rs` | Only re-exports, no logic |
| Retina capture loop | `#[filter("udp")]` captures all UDP — platform filtering happens in `quick_precheck` |
| Batch queue / session worker loop | The `Batch` struct and worker loop don't care about platform — records carry it themselves |
| InfluxDB writer thread | Already generic — just sends whatever line-protocol strings arrive |

## Grafana — How to View Meet QoE

After this change, every InfluxDB data point has a `platform` tag (`teams` or `meet`). To see Meet QoE:

```flux
from(bucket: "qoe")
  |> range(start: v.timeRangeStart, stop: v.timeRangeStop)
  |> filter(fn: (r) => r["_measurement"] == "teams_session_qoe")
  |> filter(fn: (r) => r["platform"] == "meet")   // ← new filter
  |> filter(fn: (r) => r["_field"] == "fps" or r["_field"] == "frame_jitter_ms")
  |> aggregateWindow(every: 5s, fn: mean, createEmpty: false)
```

Or add a Grafana variable `$platform` with values `teams`, `meet`, `.*` (all) to switch between them interactively.

## Verification Plan

### Automated Tests
```bash
cargo check   # type-check — ensures Platform enum threads through correctly
cargo build   # full compile with retina
```

### Manual Verification
1. Run the binary on the network.
2. Join a Google Meet call.
3. Confirm `meet_rtp_records.csv` is created and populated.
4. Confirm `teams_rtp_records.csv` still works for Teams calls.
5. Check InfluxDB for lines with `platform=meet` and `session_id=M_...`.
6. Verify Grafana queries with `platform` filter show Meet QoE metrics (FPS, jitter, throughput, loss).
