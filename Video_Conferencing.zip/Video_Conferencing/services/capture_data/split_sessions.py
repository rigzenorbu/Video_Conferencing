import os
import csv
import sys

print("Initializing Split Sessions Pipeline...")

MICROSOFT_SERVER_IPS = [
    "52.112.", "52.113.", "52.114.", "52.115.", "52.122.", "52.123.",
    "2603:1010", "2603:1027", "2603:1037", "2603:1047", "2603:1057", "2603:1063", "2620:1ec"
]

MEET_SERVER_IPS = [
    "74.125.250.", "74.125.247.128", "142.250.82.",
    "2001:4860:4864:5:", "2001:4860:4864:4:8000:", "2001:4860:4864:6:"
]

def is_teams_server(ip):
    return any(ip.startswith(prefix) for prefix in MICROSOFT_SERVER_IPS)

def is_meet_server(ip):
    return any(ip.startswith(prefix) for prefix in MEET_SERVER_IPS)

def get_client_ip(src_ip, dst_ip, platform):
    if platform == "Teams":
        return dst_ip if is_teams_server(src_ip) else src_ip
    else:
        return dst_ip if is_meet_server(src_ip) else src_ip

SESSION_TIMEOUT_NS = 120 * 1_000_000_000

def split_csv(input_file, platform, output_dir):
    if not os.path.exists(input_file):
        print(f"[WARN] File {input_file} not found.")
        return

    os.makedirs(output_dir, exist_ok=True)
    active_sessions = {}
    
    with open(input_file, 'r') as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            return 
        
        count = 0
        for row in reader:
            if not row or len(row) < 3: continue
            
            arrival_epoch_ns = int(row[0])
            src_ip, dst_ip = row[1], row[2]
            
            client_ip = get_client_ip(src_ip, dst_ip, platform)
            
            if client_ip in active_sessions:
                if arrival_epoch_ns - active_sessions[client_ip]['last_seen'] > SESSION_TIMEOUT_NS:
                    active_sessions[client_ip]['file_handle'].close()
                    del active_sessions[client_ip]
            
            if client_ip not in active_sessions:
                safe_ip = client_ip.replace(':', '_')
                filename = f"Session_{safe_ip}_{arrival_epoch_ns}.csv"
                filepath = os.path.join(output_dir, filename)
                
                file_handle = open(filepath, 'w', newline='')
                writer = csv.writer(file_handle)
                writer.writerow(header)
                
                active_sessions[client_ip] = {
                    'last_seen': arrival_epoch_ns,
                    'file_handle': file_handle,
                    'writer': writer
                }
            
            active_sessions[client_ip]['writer'].writerow(row)
            active_sessions[client_ip]['last_seen'] = arrival_epoch_ns
            
            count += 1
            if count % 500000 == 0:
                print(f"  ... processed {count} packets for {platform}")

    for state in active_sessions.values():
        state['file_handle'].close()
        
    print(f"[SUCCESS] Finished splitting {platform}. Total packets: {count}\n")

if __name__ == "__main__":
    base_dir = "Sessions_18_to_19"
    os.makedirs(base_dir, exist_ok=True)
    
    teams_input = "teams_rtp_records_18_to_19.csv"
    meet_input = "meet_rtp_records_18_to_19.csv"
    
    print(f"--- Starting Teams Processing ---")
    split_csv(teams_input, "Teams", os.path.join(base_dir, "Teams"))
    
    print(f"--- Starting Meet Processing ---")
    split_csv(meet_input, "Meet", os.path.join(base_dir, "Meet"))
    
    print(f"All Done! Check the '{base_dir}' folder.")




