use crate::models::RtpRecord;
use std::collections::HashMap;
use super::network_metrics::{is_server_ip, is_meet_server_ip};

// Valid gap range in 90kHz ticks (corresponds to 1–60 FPS)
const MIN_GAP: u32 = 1_500;  // 60 FPS
const MAX_GAP: u32 = 90_000; // 1 FPS

/// Per-SSRC tracker for Media Metrics
struct StreamState {
    /// Maps RTP timestamp → first arrival time (epoch_ns).
    /// Each unique RTP timestamp represents one video frame.
    frame_arrivals: HashMap<u32, u64>,
    /// Total bytes of all video packets (for bitrate calculation)
    total_bytes: u64,
    /// Indicates if the stream is Downlink (true) or Uplink (false)
    is_downlink: bool,
}

#[derive(Default)]
pub struct MediaMetrics {
    streams: HashMap<u32, StreamState>,
    audio_bytes: u64,
    video_bytes: u64,
}

impl MediaMetrics {
    pub fn new() -> Self {
        Self::default()
    }

    /// Called for every packet. Tracks unique RTP timestamps and
    /// their first arrival time for Downlink video packets (>400 bytes).
    pub fn process_packet(&mut self, record: &RtpRecord) {
        let (is_uplink, is_downlink) = match record.platform {
            crate::models::Platform::Teams => (is_server_ip(&record.dst_ip), is_server_ip(&record.src_ip)),
            crate::models::Platform::Meet  => (is_meet_server_ip(&record.dst_ip), is_meet_server_ip(&record.src_ip)),
        };

        if !is_uplink && !is_downlink {
            return;
        }

        // Track overall byte counts for Audio and Video seen in this bin
        if is_downlink {
            if record.udp_len <= 400 {
                self.audio_bytes += record.udp_len as u64;
            } else {
                self.video_bytes += record.udp_len as u64;
            }
        }

        // Only process video packets (>400 bytes filters out audio)
        if record.udp_len > 400 {
            let stream = self.streams.entry(record.ssrc).or_insert_with(|| StreamState {
                frame_arrivals: HashMap::new(),
                total_bytes: 0,
                is_downlink,
            });

            // Record the LAST packet's arrival time for each frame (End Time).
            // This matches the paper's definition: ET = arrival time of the
            // final packet in the frame, i.e., when the receiver has the
            // complete frame and can decode/display it.
            stream.frame_arrivals
                .entry(record.rtp_timestamp)
                .and_modify(|existing| *existing = (*existing).max(record.arrival_epoch_ns))
                .or_insert(record.arrival_epoch_ns);

            // Accumulate bytes for video bitrate calculation
            stream.total_bytes += record.udp_len as u64;
        }
    }

    /// Compute FPS, Frame Jitter, and Video Bitrate.
    ///
    /// FPS: number of unique frames / bin_duration_sec
    /// Frame Jitter: Standard deviation of inter-frame arrival gaps (ms)
    /// Video Bitrate: total_bytes * 8 / bin_duration_sec (bps)
    ///
    /// All metrics use simple average across all valid video streams.
    pub fn to_influx_fields(&self, bin_duration_sec: f64) -> String {
        let mut up_total_fps = 0.0_f64;
        let mut up_total_jitter = 0.0_f64;
        let mut up_valid_count = 0_u32;

        let mut down_total_fps = 0.0_f64;
        let mut down_total_jitter = 0.0_f64;
        let mut down_total_bitrate = 0.0_f64;
        let mut down_valid_count = 0_u32;

        for stream in self.streams.values() {
            // Need at least 2 unique timestamps to compute metrics
            if stream.frame_arrivals.len() < 2 {
                continue;
            }

            // Sort frames by RTP timestamp first — needed to validate
            // that this SSRC is real video (check tick gaps in sender order).
            let mut frames: Vec<(u32, u64)> = stream.frame_arrivals
                .iter()
                .map(|(&ts, &arrival)| (ts, arrival))
                .collect();
            frames.sort_unstable_by_key(|&(ts, _)| ts);

            // Validate: check if RTP timestamp gaps fall within video range
            let mut valid_gap_count = 0_u32;

            for i in 1..frames.len() {
                let gap = frames[i].0.wrapping_sub(frames[i - 1].0);
                if gap >= MIN_GAP && gap <= MAX_GAP {
                    valid_gap_count += 1;
                }
            }

            // Skip this stream if no valid gaps (not real video)
            if valid_gap_count == 0 {
                continue;
            }

            // ── FPS ──────────────────────────────────────────────
            if bin_duration_sec <= 0.0 {
                continue;
            }

            let stream_fps = frames.len() as f64 / bin_duration_sec;

            // ── Frame Jitter (paper-matched) ─────────────────────
            // The paper defines Frame Jitter as the standard deviation
            // of (ETᵢ − ETᵢ₋₁) for "consecutive frames received",
            // i.e., frames ordered by their End Time (arrival order
            // at the receiver), NOT by sender RTP timestamp order.
            frames.sort_unstable_by_key(|&(_, arrival)| arrival);

            let mut arrival_gaps_ms: Vec<f64> = Vec::with_capacity(frames.len() - 1);

            for i in 1..frames.len() {
                let gap_ns = frames[i].1.saturating_sub(frames[i - 1].1);
                arrival_gaps_ms.push(gap_ns as f64 / 1_000_000.0); // ns → ms
            }

            let mean_gap = arrival_gaps_ms.iter().sum::<f64>() / arrival_gaps_ms.len() as f64;

            let variance = arrival_gaps_ms.iter()
                .map(|g| (g - mean_gap) * (g - mean_gap))
                .sum::<f64>() / arrival_gaps_ms.len() as f64;

            let stream_jitter = variance.sqrt(); // standard deviation in ms

            // ── Video Bitrate (bps) ──────────────────────────────
            let stream_bitrate = (stream.total_bytes * 8) as f64 / bin_duration_sec;

            if stream.is_downlink {
                down_total_fps += stream_fps;
                down_total_jitter += stream_jitter;
                down_total_bitrate += stream_bitrate;
                down_valid_count += 1;
            } else {
                up_total_fps += stream_fps;
                up_total_jitter += stream_jitter;
                up_valid_count += 1;
            }
        }

        // Simple average across all valid video streams
        let up_fps = if up_valid_count > 0 { up_total_fps / up_valid_count as f64 } else { 0.0 };
        let up_frame_jitter_ms = if up_valid_count > 0 { up_total_jitter / up_valid_count as f64 } else { 0.0 };

        let down_fps = if down_valid_count > 0 { down_total_fps / down_valid_count as f64 } else { 0.0 };
        let down_frame_jitter_ms = if down_valid_count > 0 { down_total_jitter / down_valid_count as f64 } else { 0.0 };
        let video_bitrate_bps = if down_valid_count > 0 { down_total_bitrate / down_valid_count as f64 } else { 0.0 };

        let audio_bps = (self.audio_bytes * 8) as f64 / bin_duration_sec;
        let video_total_bps = (self.video_bytes * 8) as f64 / bin_duration_sec;

        format!("up_fps={:.2},down_fps={:.2},up_frame_jitter_ms={:.2},down_frame_jitter_ms={:.2},video_bitrate_bps={:.0},audio_bps={:.0},video_total_bps={:.0}", 
            up_fps, down_fps, up_frame_jitter_ms, down_frame_jitter_ms, video_bitrate_bps, audio_bps, video_total_bps)
    }

    /// Reset frame counters for the next 5-second window.
    pub fn reset_bin(&mut self) {
        for stream in self.streams.values_mut() {
            stream.frame_arrivals.clear();
            stream.total_bytes = 0;
        }
        self.audio_bytes = 0;
        self.video_bytes = 0;
    }
}
