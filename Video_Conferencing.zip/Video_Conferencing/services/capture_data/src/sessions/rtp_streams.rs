//! # sessions/rtp_streams.rs
//!
//! **What this file does:**
//! - Tracks individual RTP streams identified by SSRC.
//! - Classifies each SSRC as Audio or Video using **majority-based** packet
//!   size classification: if the majority of packets in a 5-second bin have
//!   `udp_len <= 400`, the stream is Audio; otherwise it is Video.
//! - Determines direction (Uplink / Downlink) based on Microsoft server IP.
//! - Per-stream per-bin metrics: packets, bytes, lost packets (seq gaps),
//!   loss percentage, and throughput (bps).
//! - Emits one InfluxDB line per active SSRC per 5-second bin into a
//!   separate measurement: `teams_rtp_stream`.

use crate::models::RtpRecord;
use super::network_metrics::{is_server_ip, is_meet_server_ip};
use std::collections::HashMap;

// Valid gap range in 90kHz ticks (corresponds to 1–60 FPS)
const MIN_GAP: u32 = 1_500;  // 60 FPS
const MAX_GAP: u32 = 90_000; // 1 FPS

// ─────────────────────────────────────────────────────────────────────────────
//  Direction
// ─────────────────────────────────────────────────────────────────────────────
#[derive(Clone, Copy, PartialEq)]
enum StreamDirection {
    Uplink,
    Downlink,
}

impl StreamDirection {
    fn as_str(&self) -> &'static str {
        match self {
            StreamDirection::Uplink => "uplink",
            StreamDirection::Downlink => "downlink",
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Per-SSRC state
// ─────────────────────────────────────────────────────────────────────────────
struct RtpStreamState {
    direction: StreamDirection,

    // Majority-based classification counters (reset each bin)
    small_packet_count: u64, // udp_len <= 400 → Audio candidate
    large_packet_count: u64, // udp_len >  400 → Video candidate

    // Payload type tracking
    payload_type: u8,

    // Per-bin traffic metrics (reset each bin)
    packets: u64,
    bytes: u64,
    lost_packets: u64,

    // Sequence tracking (persists across bins for cross-bin loss detection)
    last_seq: u16,
    first_packet_seen: bool,

    // Frame arrival tracking for per-SSRC FPS/jitter (video only)
    // Maps RTP timestamp → last (End Time) arrival in epoch_ns
    frame_arrivals: HashMap<u32, u64>,
}

// ─────────────────────────────────────────────────────────────────────────────
//  Public tracker
// ─────────────────────────────────────────────────────────────────────────────
#[derive(Default)]
pub struct RtpStreamTracker {
    streams: HashMap<u32, RtpStreamState>,
}

impl RtpStreamTracker {
    pub fn new() -> Self {
        Self::default()
    }

    /// Called for every RTP packet.  Accumulates per-SSRC metrics.
    pub fn process_packet(&mut self, record: &RtpRecord) {
        let (is_uplink, is_downlink) = match record.platform {
            crate::models::Platform::Teams => (is_server_ip(&record.dst_ip), is_server_ip(&record.src_ip)),
            crate::models::Platform::Meet  => (is_meet_server_ip(&record.dst_ip), is_meet_server_ip(&record.src_ip)),
        };

        // Skip packets that don't involve a Microsoft relay
        if !is_uplink && !is_downlink {
            return;
        }

        let direction = if is_uplink {
            StreamDirection::Uplink
        } else {
            StreamDirection::Downlink
        };

        let state = self
            .streams
            .entry(record.ssrc)
            .or_insert_with(|| RtpStreamState {
                direction,
                small_packet_count: 0,
                large_packet_count: 0,
                payload_type: record.payload_type,
                packets: 0,
                bytes: 0,
                lost_packets: 0,
                last_seq: record.seq_num,
                first_packet_seen: false,
                frame_arrivals: HashMap::new(),
            });

        // ── Size classification ──────────────────────────────────────────
        if record.udp_len <= 400 {
            state.small_packet_count += 1;
        } else {
            state.large_packet_count += 1;
        }

        // Track frame arrivals for video packets (FPS / jitter)
        // Uses End Time: stores the LAST packet arrival per frame,
        // matching the paper's definition.
        if record.udp_len > 400 {
            state.frame_arrivals
                .entry(record.rtp_timestamp)
                .and_modify(|existing| *existing = (*existing).max(record.arrival_epoch_ns))
                .or_insert(record.arrival_epoch_ns);
        }

        // ── Packet loss (sequence-gap detection) ─────────────────────────
        if state.first_packet_seen {
            let diff = record.seq_num.wrapping_sub(state.last_seq) as i16;
            if diff > 1 {
                state.lost_packets += (diff as u64) - 1;
            }
            if diff > 0 {
                state.last_seq = record.seq_num;
            }
        } else {
            state.first_packet_seen = true;
        }

        state.payload_type = record.payload_type; // Update payload type just in case
        state.packets += 1;
        state.bytes += record.udp_len as u64;
    }

    /// Returns InfluxDB line-protocol entries, one per active SSRC.
    ///
    /// `client_tag` and `session_tag` must already be InfluxDB-escaped
    /// (the caller in `flush_session` handles this).
    pub fn to_influx_lines(
        &self,
        client_tag: &str,
        session_tag: &str,
        platform_tag: &str,
        bin_duration_sec: f64,
        timestamp_ns: u64,
    ) -> Vec<String> {
        let mut lines = Vec::new();

        for (&ssrc, state) in &self.streams {
            if state.packets == 0 {
                continue;
            }

            // Majority-based classification
            let stream_type = if state.large_packet_count > state.small_packet_count {
                "video"
            } else {
                "audio"
            };

            let throughput_bps = (state.bytes as f64 * 8.0) / bin_duration_sec;
            let expected = state.packets + state.lost_packets;
            let loss_pct = if expected > 0 {
                (state.lost_packets as f64 / expected as f64) * 100.0
            } else {
                0.0
            };

            // ── Per-SSRC FPS and Frame Jitter (paper-matched) ────────
            let (fps, frame_jitter_ms) = if state.frame_arrivals.len() >= 2 {
                let mut frames: Vec<(u32, u64)> = state.frame_arrivals
                    .iter()
                    .map(|(&ts, &arrival)| (ts, arrival))
                    .collect();

                // Validate: sort by RTP timestamp, check tick gaps
                frames.sort_unstable_by_key(|&(ts, _)| ts);
                let valid = (1..frames.len()).any(|i| {
                    let gap = frames[i].0.wrapping_sub(frames[i - 1].0);
                    gap >= MIN_GAP && gap <= MAX_GAP
                });

                if valid && bin_duration_sec > 0.0 {
                    let fps = frames.len() as f64 / bin_duration_sec;

                    // Sort by arrival End Time for jitter (paper: "consecutive
                    // frames received", i.e., receiver order).
                    frames.sort_unstable_by_key(|&(_, arrival)| arrival);

                    let gaps_ms: Vec<f64> = (1..frames.len())
                        .map(|i| {
                            frames[i].1.saturating_sub(frames[i - 1].1) as f64
                                / 1_000_000.0
                        })
                        .collect();

                    let mean = gaps_ms.iter().sum::<f64>() / gaps_ms.len() as f64;
                    let variance = gaps_ms.iter()
                        .map(|g| (g - mean) * (g - mean))
                        .sum::<f64>() / gaps_ms.len() as f64;
                    let jitter = variance.sqrt();

                    (fps, jitter)
                } else {
                    (0.0, 0.0)
                }
            } else {
                (0.0, 0.0)
            };

            let line = format!(
                "teams_rtp_stream,client_ip={},session_id={},ssrc=0x{:08X},stream_type={},direction={},platform={},pt={} \
                 packets={}i,bytes={}i,lost_packets={}i,loss_pct={:.4},throughput_bps={:.2},fps={:.2},frame_jitter_ms={:.4} {}",
                client_tag,
                session_tag,
                ssrc,
                stream_type,
                state.direction.as_str(),
                platform_tag,
                state.payload_type,
                state.packets,
                state.bytes,
                state.lost_packets,
                loss_pct,
                throughput_bps,
                fps,
                frame_jitter_ms,
                timestamp_ns,
            );

            lines.push(line);
        }

        lines
    }

    /// Reset per-bin counters.  Keeps SSRC entries, sequence state, 
    /// and size classifications so that cross-bin loss detection and 
    /// audio/video stream tagging remains accurate and stable.
    pub fn reset_bin(&mut self) {
        for state in self.streams.values_mut() {
            // We DO NOT reset small_packet_count and large_packet_count here!
            // By accumulating these over the lifetime of the SSRC, the stream_type
            // classification remains highly stable even if a video stream temporarily
            // sends small packets during a static scene.
            state.packets = 0;
            state.bytes = 0;
            state.lost_packets = 0;
            state.frame_arrivals.clear();
            // last_seq and first_packet_seen are intentionally preserved
        }
    }
}
